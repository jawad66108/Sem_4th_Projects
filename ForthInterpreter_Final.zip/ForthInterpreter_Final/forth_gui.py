import tkinter as tk
from tkinter import ttk, messagebox
import time
import random

class SplashScreen:
    def __init__(self, root):
        self.root = root
        self.root.overrideredirect(True)
        
        self.screen_width = self.root.winfo_screenwidth()
        self.screen_height = self.root.winfo_screenheight()
        
        self.width = self.screen_width - 100
        self.height = self.screen_height - 100
        x = (self.screen_width - self.width) // 2
        y = (self.screen_height - self.height) // 2
        self.root.geometry(f'{self.width}x{self.height}+{x}+{y}')
        
        self.main_frame = tk.Frame(self.root, bg='#050505')
        self.main_frame.pack(fill=tk.BOTH, expand=True)
        
        self.canvas = tk.Canvas(self.main_frame, width=self.width, height=self.height, 
                                bg='#050505', highlightthickness=0)
        self.canvas.pack(fill=tk.BOTH, expand=True)
        
        self.dots = []
        self.create_matrix_background()
        
        for r in range(150, 50, -10):
            self.canvas.create_oval(self.width//2 - r, self.height//2 - r,
                                    self.width//2 + r, self.height//2 + r,
                                    outline='#00d4ff', width=1, stipple='gray50')
        
        self.title_main = self.canvas.create_text(self.width//2 - 4, self.height//2 - 84,
                                text="FORTH", font=("Orbitron", 72, "bold"), fill="#00d4ff")
        
        self.subtitle = self.canvas.create_text(self.width//2, self.height//2 - 20,
                                text="INTERPRETER", font=("Orbitron", 44, "bold"), fill="#ff6b35")
        
        self.canvas.create_text(self.width//2, self.height//2 + 30,
                                text="Stack-Based Language | x86-64 Assembly",
                                font=("Consolas", 14), fill="#888888")
        
        self.canvas.create_rectangle(self.width//2 - 90, self.height//2 + 60,
                                     self.width//2 + 90, self.height//2 + 90,
                                     fill="#1a1a2e", outline="#00d4ff", width=2)
        self.canvas.create_text(self.width//2, self.height//2 + 75,
                                text="PROFESSIONAL EDITION", font=("Consolas", 11, "bold"), fill="#00d4ff")
        
        self.loading_canvas = tk.Canvas(self.main_frame, width=self.width-200, height=40,
                                        bg='#050505', highlightthickness=0)
        self.loading_canvas.place(x=100, y=self.height-120)
        
        self.loading_bg = self.loading_canvas.create_rectangle(0, 5, self.width-200, 35,
                                                                fill='#1a1a2e', outline='#00d4ff', width=2)
        self.loading_fill = self.loading_canvas.create_rectangle(0, 5, 0, 35,
                                                                 fill='#00d4ff', outline='')
        
        self.loading_text = self.canvas.create_text(self.width//2, self.height-85,
                                                    text="INITIALIZING 0%", font=("Consolas", 12, "bold"), fill="#00d4ff")
        
        self.canvas.create_text(self.width//2, self.height-40,
                                text="Computer Organization & Assembly Language Project | 4th Semester",
                                font=("Arial", 9), fill="#444444")
        
        self.angle = 0
        self.animate_title()
        self.animate_matrix()
        self.load_progress()
    
    def create_matrix_background(self):
        for i in range(80):
            x = random.randint(0, self.width)
            y = random.randint(0, self.height)
            dot = self.canvas.create_text(x, y, text="•", font=("Consolas", random.randint(8, 16)), fill="#00d4ff")
            self.dots.append(dot)
    
    def animate_matrix(self):
        for dot in self.dots:
            self.canvas.move(dot, 0, random.randint(1, 3))
            coords = self.canvas.coords(dot)
            if coords[1] > self.height:
                self.canvas.coords(dot, random.randint(0, self.width), 0)
        self.root.after(50, self.animate_matrix)
    
    def animate_title(self):
        colors = ['#00d4ff', '#00ff88', '#ff6b35', '#ff00ff', '#00d4ff']
        self.canvas.itemconfig(self.title_main, fill=colors[self.angle % len(colors)])
        self.angle += 1
        self.root.after(200, self.animate_title)
    
    def load_progress(self):
        self.value = 0
        self.update_progress(0)
    
    def update_progress(self, value):
        if value <= 100:
            width = (value / 100) * (self.width - 200)
            self.loading_canvas.coords(self.loading_fill, 0, 5, width, 35)
            
            messages = ["INITIALIZING CORE MODULES", "LOADING STACK ENGINE", "PARSING ASSEMBLY CODE", "INITIALIZING GUI COMPONENTS", "STARTING FORTH INTERPRETER"]
            idx = min(value // 20, 4)
            self.canvas.itemconfig(self.loading_text, text=f"{messages[idx]} {value}%")
            
            self.root.after(20, lambda: self.update_progress(value + random.randint(2, 4)))
        else:
            self.root.after(500, self.close_splash)
    
    def close_splash(self):
        self.root.destroy()

class ForthProfessionalGUI:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Forth Interpreter - Assembly x86-64 | Professional Edition")
        
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()
        self.root.geometry(f"{screen_width-50}x{screen_height-80}")
        self.root.configure(bg='#050505')
        self.root.minsize(1300, 750)
        
        self.stack = []
        self.running = True
        self.history = []
        self.command_log = []  # New: Command log for separate section
        
        self.create_menu_bar()
        self.create_main_layout()
        self.setup_shortcuts()
        
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)
        self.update_stack_display()
        self.update_command_log()
    
    def create_menu_bar(self):
        menubar = tk.Menu(self.root, bg='#050505', fg='#00d4ff', activebackground='#1a1a2e')
        self.root.config(menu=menubar)
        
        file_menu = tk.Menu(menubar, tearoff=0, bg='#050505', fg='#00d4ff')
        menubar.add_cascade(label="File", menu=file_menu)
        file_menu.add_command(label="Clear Stack", command=self.clear_stack, accelerator="Ctrl+C")
        file_menu.add_command(label="Clear Log", command=self.clear_log, accelerator="Ctrl+Shift+L")
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self.on_closing, accelerator="Ctrl+Q")
        
        edit_menu = tk.Menu(menubar, tearoff=0, bg='#050505', fg='#00d4ff')
        menubar.add_cascade(label="Edit", menu=edit_menu)
        edit_menu.add_command(label="Clear Output", command=self.clear_output, accelerator="Ctrl+L")
        
        help_menu = tk.Menu(menubar, tearoff=0, bg='#050505', fg='#00d4ff')
        menubar.add_cascade(label="Help", menu=help_menu)
        help_menu.add_command(label="About", command=self.show_about)
    
    def create_main_layout(self):
        # Header
        header_frame = tk.Frame(self.root, bg='#050505', height=90)
        header_frame.pack(fill=tk.X, padx=30, pady=(15,10))
        header_frame.pack_propagate(False)
        
        title_label = tk.Label(header_frame, text="FORTH INTERPRETER",
                              font=('Orbitron', 22, 'bold'), fg='#00d4ff', bg='#050505')
        title_label.pack(pady=(15,5))
        
        subtitle_label = tk.Label(header_frame, 
                                 text="Stack-Based Language | x86-64 Assembly | Professional Edition",
                                 font=('Arial', 10), fg='#ff6b35', bg='#050505')
        subtitle_label.pack()
        
        separator = tk.Frame(self.root, height=2, bg='#1a1a2e')
        separator.pack(fill=tk.X, padx=30, pady=10)
        
        # Main content - 3 columns now (Stack | RightPanel | CommandLog)
        main_frame = tk.Frame(self.root, bg='#050505')
        main_frame.pack(fill=tk.BOTH, expand=True, padx=30, pady=10)
        
        # ==================== COLUMN 1: STACK PANEL ====================
        left_panel = tk.Frame(main_frame, bg='#050505')
        left_panel.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        stack_frame = tk.LabelFrame(left_panel, text=" STACK VISUALIZATION ",
                                    font=('Orbitron', 11, 'bold'), fg='#00d4ff', bg='#050505',
                                    relief=tk.RIDGE, borderwidth=3)
        stack_frame.pack(fill=tk.BOTH, expand=True)
        
        stack_container = tk.Frame(stack_frame, bg='#050505')
        stack_container.pack(fill=tk.BOTH, expand=True, padx=15, pady=15)
        
        self.stack_listbox = tk.Listbox(stack_container, height=20,
                                        font=('Consolas', 11), bg='#0a0a0a', fg='#00d4ff',
                                        selectbackground='#ff6b35', relief=tk.FLAT,
                                        borderwidth=0, highlightthickness=0)
        self.stack_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        stack_scrollbar = tk.Scrollbar(stack_container, orient=tk.VERTICAL, command=self.stack_listbox.yview, bg='#050505')
        stack_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.stack_listbox.config(yscrollcommand=stack_scrollbar.set)
        
        stack_info = tk.Frame(stack_frame, bg='#050505')
        stack_info.pack(fill=tk.X, padx=15, pady=(0,15))
        
        self.stack_size_label = tk.Label(stack_info, text="Stack Size: 0",
                                        font=('Consolas', 10), fg='#666666', bg='#050505')
        self.stack_size_label.pack(side=tk.LEFT)
        
        self.stack_capacity_label = tk.Label(stack_info, text="Capacity: Unlimited",
                                            font=('Consolas', 10), fg='#666666', bg='#050505')
        self.stack_capacity_label.pack(side=tk.RIGHT)
        
        # ==================== COLUMN 2: RIGHT PANEL WITH SCROLLBAR ====================
        right_panel_container = tk.Frame(main_frame, bg='#050505', width=500)
        right_panel_container.pack(side=tk.LEFT, fill=tk.BOTH, padx=(15,0))
        right_panel_container.pack_propagate(False)
        
        # Canvas for scrolling
        self.right_canvas = tk.Canvas(right_panel_container, bg='#050505', highlightthickness=0)
        self.right_scrollbar = tk.Scrollbar(right_panel_container, orient=tk.VERTICAL, command=self.right_canvas.yview)
        self.right_canvas.configure(yscrollcommand=self.right_scrollbar.set)
        
        self.right_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.right_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        # Scrollable frame inside canvas
        self.right_scrollable_frame = tk.Frame(self.right_canvas, bg='#050505')
        self.right_canvas.create_window((0, 0), window=self.right_scrollable_frame, anchor="nw", width=480)
        
        self.right_scrollable_frame.bind("<Configure>", lambda e: self.right_canvas.configure(scrollregion=self.right_canvas.bbox("all")))
        
        # Number pad
        num_frame = tk.LabelFrame(self.right_scrollable_frame, text=" NUMBER PAD ",
                                  font=('Orbitron', 11, 'bold'), fg='#00d4ff', bg='#050505',
                                  relief=tk.RIDGE, borderwidth=3)
        num_frame.pack(fill=tk.X, pady=(0,10), padx=5)
        
        num_container = tk.Frame(num_frame, bg='#050505')
        num_container.pack(padx=15, pady=15)
        
        numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
        row, col = 0, 0
        for num in numbers:
            btn = tk.Button(num_container, text=str(num), 
                           command=lambda n=num: self.execute_command(str(n)),
                           width=6, height=1, bg='#1a1a2e', fg='#00d4ff',
                           font=('Arial', 11, 'bold'), relief=tk.RAISED,
                           borderwidth=2, cursor='hand2')
            btn.grid(row=row, column=col, padx=6, pady=6)
            col += 1
            if col > 4:
                col = 0
                row += 1
        
        custom_frame = tk.Frame(num_container, bg='#050505')
        custom_frame.grid(row=row+1, column=0, columnspan=5, pady=(12,0))
        
        tk.Label(custom_frame, text="› Custom:", fg='#ff6b35', bg='#050505',
                font=('Arial', 10, 'bold')).pack(side=tk.LEFT, padx=(0,10))
        
        self.custom_entry = tk.Entry(custom_frame, width=10, bg='#0a0a0a', fg='#00d4ff',
                                     font=('Consolas', 11), relief=tk.FLAT, 
                                     insertbackground='#00d4ff')
        self.custom_entry.pack(side=tk.LEFT, padx=(0,10))
        
        custom_btn = tk.Button(custom_frame, text="PUSH", 
                              command=lambda: self.execute_command(self.custom_entry.get()),
                              bg='#ff6b35', fg='#050505', font=('Arial', 10, 'bold'),
                              relief=tk.RAISED, cursor='hand2', width=7)
        custom_btn.pack(side=tk.LEFT)
        
        # Operations
        ops_frame = tk.LabelFrame(self.right_scrollable_frame, text=" OPERATIONS ",
                                  font=('Orbitron', 11, 'bold'), fg='#00d4ff', bg='#050505',
                                  relief=tk.RIDGE, borderwidth=3)
        ops_frame.pack(fill=tk.X, pady=(0,10), padx=5)
        
        ops_container = tk.Frame(ops_frame, bg='#050505')
        ops_container.pack(padx=15, pady=15)
        
        operations = [
            ('ADD', '+'), ('SUB', '-'), ('MUL', '*'), ('DIV', '/'),
            ('MOD', 'mod'), ('DUP', 'dup'), ('SWAP', 'swap'),
            ('DROP', 'drop'), ('OVER', 'over'), ('ROT', 'rot')
        ]
        
        row, col = 0, 0
        for text, cmd in operations:
            btn = tk.Button(ops_container, text=text, command=lambda c=cmd: self.execute_command(c),
                           width=8, height=1, bg='#1a1a2e', fg='#00d4ff',
                           font=('Arial', 10, 'bold'), relief=tk.RAISED,
                           borderwidth=2, cursor='hand2')
            btn.grid(row=row, column=col, padx=4, pady=4)
            col += 1
            if col > 2:
                col = 0
                row += 1
        
        # Output controls
        output_frame = tk.LabelFrame(self.right_scrollable_frame, text=" OUTPUT & CONTROL ",
                                     font=('Orbitron', 11, 'bold'), fg='#00d4ff', bg='#050505',
                                     relief=tk.RIDGE, borderwidth=3)
        output_frame.pack(fill=tk.X, pady=(0,10), padx=5)
        
        output_container = tk.Frame(output_frame, bg='#050505')
        output_container.pack(padx=15, pady=15)
        
        output_ops = [
            ('PRINT (.)', '.'), ('EMIT', 'emit'), ('CR', 'cr'),
            ('SPACE', 'space'), ('CLEAR', 'clear'), ('BYE', 'bye')
        ]
        
        row, col = 0, 0
        for text, cmd in output_ops:
            btn = tk.Button(output_container, text=text, command=lambda c=cmd: self.execute_command(c),
                           width=10, height=1, bg='#1a1a2e', fg='#00d4ff',
                           font=('Arial', 10, 'bold'), relief=tk.RAISED,
                           borderwidth=2, cursor='hand2')
            btn.grid(row=row, column=col, padx=4, pady=4)
            col += 1
            if col > 2:
                col = 0
                row += 1
        
        # Console
        console_frame = tk.LabelFrame(self.right_scrollable_frame, text=" INPUT CONSOLE ",
                                      font=('Orbitron', 11, 'bold'), fg='#00d4ff', bg='#050505',
                                      relief=tk.RIDGE, borderwidth=3)
        console_frame.pack(fill=tk.X, pady=(0,10), padx=5)
        
        input_container = tk.Frame(console_frame, bg='#050505')
        input_container.pack(fill=tk.X, padx=15, pady=15)
        
        tk.Label(input_container, text="›", fg='#00d4ff', bg='#050505',
                font=('Consolas', 16, 'bold')).pack(side=tk.LEFT, padx=(0,10))
        
        self.input_entry = tk.Entry(input_container, font=('Consolas', 12),
                                   bg='#0a0a0a', fg='#00d4ff', relief=tk.FLAT,
                                   insertbackground='#00d4ff')
        self.input_entry.pack(side=tk.LEFT, fill=tk.X, expand=True)
        self.input_entry.bind('<Return>', lambda e: self.execute_command(self.input_entry.get()))
        
        output_display = tk.Frame(console_frame, bg='#050505')
        output_display.pack(fill=tk.BOTH, expand=True, padx=15, pady=(0,15))
        
        self.output_text = tk.Text(output_display, height=8,
                                  font=('Consolas', 10), bg='#0a0a0a',
                                  fg='#00d4ff', relief=tk.FLAT, wrap=tk.WORD)
        self.output_text.pack(fill=tk.BOTH, expand=True)
        
        self.output_text.tag_config('success', foreground='#00ff88')
        self.output_text.tag_config('error', foreground='#ff4444')
        self.output_text.tag_config('info', foreground='#ff6b35')
        
        # ==================== COLUMN 3: COMMAND LOG PANEL ====================
        log_panel = tk.Frame(main_frame, bg='#050505', width=350)
        log_panel.pack(side=tk.RIGHT, fill=tk.BOTH, padx=(15,0))
        log_panel.pack_propagate(False)
        
        log_frame = tk.LabelFrame(log_panel, text=" COMMAND LOG / HISTORY ",
                                  font=('Orbitron', 11, 'bold'), fg='#00d4ff', bg='#050505',
                                  relief=tk.RIDGE, borderwidth=3)
        log_frame.pack(fill=tk.BOTH, expand=True)
        
        log_container = tk.Frame(log_frame, bg='#050505')
        log_container.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        self.command_log_listbox = tk.Listbox(log_container, height=25,
                                              font=('Consolas', 10), bg='#0a0a0a', fg='#00d4ff',
                                              selectbackground='#ff6b35', relief=tk.FLAT,
                                              borderwidth=0, highlightthickness=0)
        self.command_log_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        log_scrollbar = tk.Scrollbar(log_container, orient=tk.VERTICAL, command=self.command_log_listbox.yview, bg='#050505')
        log_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.command_log_listbox.config(yscrollcommand=log_scrollbar.set)
        
        log_info = tk.Frame(log_frame, bg='#050505')
        log_info.pack(fill=tk.X, padx=10, pady=(0,10))
        
        log_count_label = tk.Label(log_info, text="Command History",
                                   font=('Consolas', 9), fg='#666666', bg='#050505')
        log_count_label.pack(side=tk.LEFT)
        
        clear_log_btn = tk.Button(log_info, text="Clear Log", command=self.clear_log,
                                 bg='#ff6b35', fg='#050505', font=('Arial', 8, 'bold'),
                                 relief=tk.RAISED, cursor='hand2', width=8)
        clear_log_btn.pack(side=tk.RIGHT)
        
        # Status bar
        self.status_bar = tk.Label(self.root, text="✓ SYSTEM READY | Forth Interpreter Active",
                                  font=('Consolas', 9), bg='#0a0a0a', fg='#666666',
                                  relief=tk.SUNKEN, anchor=tk.W)
        self.status_bar.pack(side=tk.BOTTOM, fill=tk.X)
    
    def setup_shortcuts(self):
        self.root.bind('<Control-c>', lambda e: self.clear_stack())
        self.root.bind('<Control-q>', lambda e: self.on_closing())
        self.root.bind('<Control-l>', lambda e: self.clear_output())
        self.root.bind('<Control-Shift-L>', lambda e: self.clear_log())
    
    def add_to_log(self, cmd, result=""):
        timestamp = time.strftime("%H:%M:%S")
        log_entry = f"[{timestamp}] > {cmd}"
        if result:
            log_entry += f" → {result}"
        
        self.command_log.append(log_entry)
        if len(self.command_log) > 100:
            self.command_log.pop(0)
        self.update_command_log()
    
    def update_command_log(self):
        self.command_log_listbox.delete(0, tk.END)
        for entry in self.command_log:
            self.command_log_listbox.insert(tk.END, entry)
        if self.command_log:
            self.command_log_listbox.see(tk.END)
    
    def clear_log(self):
        self.command_log = []
        self.update_command_log()
        self.output_text.insert(tk.END, "└── Command log cleared ✓\n\n", 'success')
    
    def execute_command(self, cmd):
        if not cmd or not self.running:
            return
        
        cmd = str(cmd).strip().lower()
        
        self.history.append(cmd)
        if len(self.history) > 50:
            self.history.pop(0)
        
        # Add to command log
        self.add_to_log(cmd)
        
        self.output_text.insert(tk.END, f"┌──► {cmd}\n", 'info')
        self.output_text.see(tk.END)
        
        self.status_bar.config(text=f"⚡ PROCESSING: {cmd}")
        self.root.update()
        time.sleep(0.02)
        
        result_value = None
        
        if cmd == 'bye':
            self.on_closing()
        elif cmd == 'clear':
            self.stack = []
            self.output_text.insert(tk.END, "└── Stack cleared ✓\n\n", 'success')
            self.update_stack_display()
        elif cmd == 'emit':
            if self.stack:
                val = self.stack.pop()
                self.output_text.insert(tk.END, f"└── Character: '{chr(val % 128)}'\n\n", 'success')
                self.update_stack_display()
        elif cmd in ['cr', 'space']:
            self.output_text.insert(tk.END, "\n", 'output')
        elif cmd == '.':
            if self.stack:
                val = self.stack.pop()
                self.output_text.insert(tk.END, f"└── Result: {val}\n\n", 'success')
                self.update_stack_display()
                result_value = val
            else:
                self.output_text.insert(tk.END, "└── ✗ Stack empty\n\n", 'error')
        elif cmd in ['+', '-', '*', '/', 'mod']:
            if len(self.stack) >= 2:
                b = self.stack.pop()
                a = self.stack.pop()
                if cmd == '+': result = a + b
                elif cmd == '-': result = a - b
                elif cmd == '*': result = a * b
                elif cmd == 'mod': 
                    if b == 0:
                        self.output_text.insert(tk.END, "└── ✗ Division by zero!\n\n", 'error')
                        self.stack.extend([a, b])
                        return
                    result = a % b
                elif cmd == '/':
                    if b == 0:
                        self.output_text.insert(tk.END, "└── ✗ Division by zero!\n\n", 'error')
                        self.stack.extend([a, b])
                        return
                    result = a // b
                self.stack.append(result)
                self.output_text.insert(tk.END, f"└── {a} {cmd} {b} = {result} ✓\n\n", 'success')
                self.update_stack_display()
                result_value = result
            else:
                self.output_text.insert(tk.END, "└── ✗ Need 2 values\n\n", 'error')
        elif cmd in ['dup', 'swap', 'drop', 'over', 'rot']:
            if cmd == 'dup':
                if self.stack:
                    self.stack.append(self.stack[-1])
                    self.output_text.insert(tk.END, f"└── Duplicated ✓\n\n", 'success')
            elif cmd == 'swap':
                if len(self.stack) >= 2:
                    self.stack[-1], self.stack[-2] = self.stack[-2], self.stack[-1]
                    self.output_text.insert(tk.END, f"└── Swapped ✓\n\n", 'success')
                else:
                    self.output_text.insert(tk.END, "└── ✗ Need 2 values\n\n", 'error')
            elif cmd == 'drop':
                if self.stack:
                    val = self.stack.pop()
                    self.output_text.insert(tk.END, f"└── Dropped: {val} ✓\n\n", 'success')
                else:
                    self.output_text.insert(tk.END, "└── ✗ Stack empty\n\n", 'error')
            elif cmd == 'over':
                if len(self.stack) >= 2:
                    val = self.stack[-2]
                    self.stack.append(val)
                    self.output_text.insert(tk.END, f"└── Over: copied {val} ✓\n\n", 'success')
                else:
                    self.output_text.insert(tk.END, "└── ✗ Need 2 values\n\n", 'error')
            elif cmd == 'rot':
                if len(self.stack) >= 3:
                    a, b, c = self.stack[-3], self.stack[-2], self.stack[-1]
                    self.stack[-3:] = [b, c, a]
                    self.output_text.insert(tk.END, f"└── Rotated ✓\n\n", 'success')
                else:
                    self.output_text.insert(tk.END, "└── ✗ Need 3 values\n\n", 'error')
            self.update_stack_display()
        elif cmd.isdigit() or (cmd[0] == '-' and cmd[1:].isdigit()):
            self.stack.append(int(cmd))
            self.output_text.insert(tk.END, f"└── Pushed: {cmd} ✓\n\n", 'success')
            self.update_stack_display()
            result_value = cmd
        else:
            self.output_text.insert(tk.END, f"└── ✗ Unknown: '{cmd}'\n\n", 'error')
        
        self.input_entry.delete(0, tk.END)
        self.custom_entry.delete(0, tk.END)
        
        # Update log with result if available
        if result_value:
            self.command_log[-1] = self.command_log[-1] + f" → {result_value}"
            self.update_command_log()
        
        self.status_bar.config(text=f"✓ READY | Stack: {len(self.stack)} items | History: {len(self.command_log)} commands")
        self.output_text.see(tk.END)
    
    def update_stack_display(self):
        self.stack_listbox.delete(0, tk.END)
        if self.stack:
            for i, val in enumerate(reversed(self.stack)):
                if i == 0:
                    prefix = "🔝 TOP → "
                elif i == 1:
                    prefix = "📌       "
                else:
                    prefix = "         "
                self.stack_listbox.insert(tk.END, f"{prefix}{i}: {val}")
        else:
            self.stack_listbox.insert(tk.END, "   📭  EMPTY STACK")
        
        self.stack_size_label.config(text=f"Stack Size: {len(self.stack)}")
    
    def clear_stack(self):
        self.stack = []
        self.update_stack_display()
        self.output_text.insert(tk.END, "└── Stack cleared ✓\n\n", 'success')
        self.status_bar.config(text="✓ Stack cleared")
    
    def clear_output(self):
        self.output_text.delete(1.0, tk.END)
        self.output_text.insert(tk.END, "┌── Console cleared\n", 'info')
    
    def show_about(self):
        about_text = """
╔═══════════════════════════════════════════════════════════════════╗
║                    FORTH INTERPRETER v3.0                         ║
╠═══════════════════════════════════════════════════════════════════╣
║  Assembly Language Project - Computer Organization                ║
║  Stack-Based Language Implementation in x86-64 NASM               ║
║                                                                   ║
║  ✨ FEATURES:                                                     ║
║  • Professional dark theme GUI                                    ║
║  • Animated matrix-style splash screen                            ║
║  • Real-time stack visualization                                  ║
║  • Number pad (1-10) + custom input                               ║
║  • Full arithmetic and stack operations                           ║
║  • Separate COMMAND LOG section for history                       ║
║  • Scrollable right panel                                         ║
║  • Keyboard shortcuts (Ctrl+C, Ctrl+Q, Ctrl+L, Ctrl+Shift+L)     ║
║                                                                   ║
║  🎓 Developed for: 4th Semester, Computer Science                 ║
║  📅 Academic Year: 2026                                          ║
╚═══════════════════════════════════════════════════════════════════╝
"""
        self.output_text.insert(tk.END, about_text + "\n", 'info')
        self.output_text.see(tk.END)
    
    def on_closing(self):
        if messagebox.askokcancel("Exit", "Do you want to exit the Forth Interpreter?"):
            self.running = False
            self.root.destroy()
    
    def run(self):
        self.root.mainloop()

if __name__ == "__main__":
    splash_root = tk.Tk()
    splash = SplashScreen(splash_root)
    splash_root.after(5000, lambda: splash_root.destroy())
    splash_root.mainloop()
    
    app = ForthProfessionalGUI()
    app.run()