; ============================================================
; controlflow.asm — Module 3: Control Flow Operations
; Member 3 — IF/ELSE/THEN and BEGIN/UNTIL interpreter support
; NASM x86-64 Linux
;
; Design: token-by-token interpreter state machine
;
;   skip_depth   — when >0, tokens are suppressed (we are in
;                  a false branch).  Each nested IF increments,
;                  each THEN decrements so nesting works.
;
;   in_else      — 1 when we just flipped from false-IF into
;                  the ELSE branch (now executing).
;
;   begin_sp / begin_stack — a small software return-stack that
;                  stores the byte-address (index in input buf)
;                  of each BEGIN so UNTIL can rewind and re-parse.
;
;   The parser calls cf_should_skip() before executing every
;   token; if it returns 1 the token is dropped.  Special words
;   (IF, ELSE, THEN) are always forwarded to controlflow so the
;   nesting counters stay correct.
; ============================================================

section .data
    skip_depth  dq 0            ; nesting level of false branches
    in_else     dq 0            ; 1 = currently in an ELSE branch

    ; BEGIN/UNTIL return stack (max 16 nested loops)
    BEGIN_STACK_MAX equ 16
    begin_stack times BEGIN_STACK_MAX dq 0   ; stores pointer values
    begin_sp    dq 0                          ; index into begin_stack

    ; Error / info messages
    msg_cf_err_then  db '[CF] THEN without matching IF', 10, 0
    msg_cf_err_else  db '[CF] ELSE without matching IF', 10, 0
    msg_cf_err_until db '[CF] UNTIL without matching BEGIN', 10, 0
    msg_cf_err_loop  db '[CF] BEGIN stack overflow', 10, 0

section .text
    extern stack_pop, stack_push

    ; Public interface used by parser.asm
    global cf_init
    global cf_should_skip      ; returns 1 if current token must be skipped
    global control_if
    global control_else
    global control_then
    global control_begin       ; call with rdi = pointer to BEGIN token in buf
    global control_until       ; returns rdi = address to re-parse from, or 0

; ── helpers ────────────────────────────────────────────────

print_msg:                      ; rsi = null-terminated string
    push rax
    push rdx
    push rdi
    mov  rdx, 0
.len:
    cmp  byte [rsi + rdx], 0
    je   .got
    inc  rdx
    jmp  .len
.got:
    mov  rax, 1
    mov  rdi, 1
    syscall
    pop  rdi
    pop  rdx
    pop  rax
    ret

; ── cf_init ────────────────────────────────────────────────
; Reset all control-flow state.  Call once at startup.
cf_init:
    mov  qword [skip_depth], 0
    mov  qword [in_else],    0
    mov  qword [begin_sp],   0
    ret

; ── cf_should_skip ─────────────────────────────────────────
; Returns rax = 1 if the current token should be suppressed,
;              0 if it should be executed normally.
; Does NOT consume the token — the parser still needs to check
; whether the token is IF/ELSE/THEN so nesting stays correct.
cf_should_skip:
    mov  rax, [skip_depth]
    cmp  rax, 0
    jg   .yes
    mov  rax, 0
    ret
.yes:
    mov  rax, 1
    ret

; ── control_if ─────────────────────────────────────────────
; Pops TOS.  If 0 (false) → increment skip_depth (enter skip).
; If nonzero (true) → nothing, continue executing.
; Called by the parser even when already skipping (for nesting).
control_if:
    push rbp
    mov  rbp, rsp

    ; If we are already skipping, just deepen the nesting
    mov  rax, [skip_depth]
    cmp  rax, 0
    jg   .already_skipping

    ; Normal path: evaluate condition
    call stack_pop              ; rax = condition
    cmp  rax, 0
    jne  .true_branch           ; nonzero = true → execute

    ; False branch: start skipping
    mov  qword [skip_depth], 1
    mov  qword [in_else],    0
    jmp  .done

.true_branch:
    ; Condition true: execute normally, skip_depth stays 0
    mov  qword [in_else], 0
    jmp  .done

.already_skipping:
    ; Nested IF inside a false branch — deepen skip counter
    inc  qword [skip_depth]

.done:
    pop  rbp
    ret

; ── control_else ───────────────────────────────────────────
; Toggles execution state between IF and ELSE branches.
control_else:
    push rbp
    mov  rbp, rsp

    mov  rax, [skip_depth]
    cmp  rax, 0
    je   .was_executing         ; we were executing → now skip

    ; We were skipping at depth 1 → this ELSE starts executing
    cmp  rax, 1
    je   .was_skipping_depth1

    ; Deeper nested false branch — ELSE doesn't flip anything
    jmp  .done

.was_executing:
    ; We executed the true branch, so skip the else branch
    mov  qword [skip_depth], 1
    mov  qword [in_else],    1
    jmp  .done

.was_skipping_depth1:
    ; We skipped the true branch → execute the else branch
    mov  qword [skip_depth], 0
    mov  qword [in_else],    1

.done:
    pop  rbp
    ret

; ── control_then ───────────────────────────────────────────
; Ends an IF/ELSE block.  Decrements skip_depth if >0.
control_then:
    push rbp
    mov  rbp, rsp

    mov  rax, [skip_depth]
    cmp  rax, 0
    je   .was_executing         ; nothing to do

    dec  rax
    mov  [skip_depth], rax

.was_executing:
    mov  qword [in_else], 0    ; always clear else flag at THEN

    pop  rbp
    ret

; ── control_begin ──────────────────────────────────────────
; rdi = pointer to the start of the BEGIN token inside the
;       input line buffer.  We save this address so UNTIL can
;       hand it back to the parser's re-parse loop.
control_begin:
    push rbp
    mov  rbp, rsp
    push rbx                    ; BUG-M3-03 FIX: save rbx (callee-saved)

    ; If we are skipping, don't push — treat as opaque
    mov  rax, [skip_depth]
    cmp  rax, 0
    jg   .done

    ; Check for stack overflow
    mov  rax, [begin_sp]
    cmp  rax, BEGIN_STACK_MAX
    jge  .overflow

    ; Push the address
    lea  rbx, [begin_stack]
    mov  [rbx + rax * 8], rdi
    inc  qword [begin_sp]
    jmp  .done

.overflow:
    mov  rsi, msg_cf_err_loop
    call print_msg

.done:
    pop  rbx                    ; BUG-M3-03 FIX: restore rbx
    pop  rbp
    ret

; ── control_until ──────────────────────────────────────────
; Pops TOS.  If 0 (false) → loop: returns the saved BEGIN
;   address in rax so the parser can re-parse from there.
; If nonzero (true) → exit loop: pops begin_stack, returns 0.
;
; Return value (rax):
;   0  = exit loop (condition was true, or error)
;   !0 = address of BEGIN token to re-parse from
control_until:
    push rbp
    mov  rbp, rsp
    push rbx                    ; BUG-M3-04 FIX: save rbx (callee-saved)

    ; If skipping, nothing to do
    mov  rax, [skip_depth]
    cmp  rax, 0
    jg   .return_zero

    ; Check begin_sp
    mov  rax, [begin_sp]
    cmp  rax, 0
    jle  .underflow

    ; Peek the BEGIN address (don't pop yet)
    lea  rbx, [begin_stack]
    mov  rcx, [begin_sp]
    dec  rcx
    mov  r8, [rbx + rcx * 8]   ; r8 = BEGIN address

    ; Pop condition from data stack
    call stack_pop              ; rax = condition

    cmp  rax, 0
    jne  .exit_loop             ; nonzero → exit (UNTIL exits when TRUE)

    ; Condition false → loop again: return BEGIN address
    mov  rax, r8
    jmp  .epilog

.exit_loop:
    ; Condition true → pop begin_stack and return 0
    dec  qword [begin_sp]
    xor  rax, rax
    jmp  .epilog

.underflow:
    mov  rsi, msg_cf_err_until
    call print_msg
    xor  rax, rax
    jmp  .epilog

.return_zero:
    xor  rax, rax

.epilog:
    pop  rbx                    ; BUG-M3-04 FIX: restore rbx
    pop  rbp
    ret
