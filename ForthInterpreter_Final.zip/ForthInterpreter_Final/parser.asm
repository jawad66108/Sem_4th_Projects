; parser.asm - Tokenization and Parsing
; Updated by Member 3: integrated IF/ELSE/THEN and BEGIN/UNTIL

section .data
    input_buffer times 256 db 0
    token_buffer times 64  db 0

    ; dictionary entries
    dict_add   db '+', 0
    dict_sub   db '-', 0
    dict_mul   db '*', 0
    dict_div   db '/', 0
    dict_mod   db '%', 0
    dict_dup   db 'd','u','p',0
    dict_drop  db 'd','r','o','p',0
    dict_swap  db 's','w','a','p',0
    dict_over  db 'o','v','e','r',0
    dict_rot   db 'r','o','t',0
    dict_dot   db '.', 0
    dict_emit  db 'e','m','i','t',0
    dict_cr    db 'c','r',0
    dict_space db 's','p','a','c','e',0
    dict_clear db 'c','l','e','a','r',0
    dict_bye   db 'b','y','e',0
    dict_help  db 'h','e','l','p',0
    dict_stack db '.','s',0

    ; --- Member 3: control-flow keywords ---
    dict_if    db 'i','f',0
    dict_else  db 'e','l','s','e',0
    dict_then  db 't','h','e','n',0
    dict_begin db 'b','e','g','i','n',0
    dict_until db 'u','n','t','i','l',0

    unknown_cmd_msg db 'Unknown command: ', 0
    prompt          db 'Forth> ', 0
    newline         db 10, 0

    help_msg1 db 'Forth Commands:', 10, 0
    help_msg2 db '  + - * / %        Arithmetic operations', 10, 0
    help_msg3 db '  dup drop swap over rot  Stack manipulation', 10, 0
    help_msg4 db '  . emit cr space  Output', 10, 0
    help_msg5 db '  clear .s         Stack display', 10, 0
    help_msg6 db '  if else then     Conditional (needs 0/nonzero on stack)', 10, 0
    help_msg7 db '  begin until      Loop (repeats until TOS nonzero)', 10, 0
    help_msg8 db '  help bye         Help and exit', 10, 0

    ; Saved pointer used by BEGIN/UNTIL re-parsing
    ; When UNTIL returns a non-zero address we restart parse_line
    ; from that point (the character after the 'n' of 'begin').
    begin_restart_ptr dq 0

section .bss
    input_read resb 256

section .text
    extern stack_push, stack_pop
    extern op_add, op_sub, op_mul, op_div, op_mod
    extern op_dup, op_drop, op_swap, op_over, op_rot
    extern op_dot, op_emit, op_cr, op_space, op_clear, op_print_stack
    extern cf_init, cf_should_skip
    extern control_if, control_else, control_then
    extern control_begin, control_until

    global parse_line, execute_token, is_number
    global get_input, show_prompt

; ── parse_line ─────────────────────────────────────────────
; void parse_line(char* line)
; Splits the line into whitespace-delimited tokens and calls
; execute_token for each one.
;
; BEGIN/UNTIL looping is handled here: after execute_token
; processes UNTIL it checks begin_restart_ptr; if non-zero the
; parser rewinds to that saved position and re-scans.
parse_line:
    push rbp
    mov  rbp, rsp
    push rbx                    ; current scan pointer
    push r12                    ; token-start pointer
    push r13                    ; in-token flag
    push r14                    ; line base (for re-parse safety)

    mov  r14, rdi               ; save line base

    ; BUG-M3-02 FIX: zero r12/r13 before scanning (could hold garbage)
    xor  r12, r12               ; token-start pointer = NULL
    xor  r13, r13               ; in-token flag = 0

    cmp  byte [rdi], 0
    je   .done

    mov  rbx, rdi               ; scan pointer = line start

.scan_loop:
    mov  al, [rbx]
    cmp  al, 0
    je   .process_last

    ; whitespace?
    cmp  al, ' '
    je   .whitespace
    cmp  al, 9
    je   .whitespace
    cmp  al, 10
    je   .whitespace
    cmp  al, 13
    je   .whitespace

    ; non-whitespace
    cmp  r13, 0
    jne  .continue_token
    mov  r12, rbx               ; token start
    mov  r13, 1

.continue_token:
    inc  rbx
    jmp  .scan_loop

.whitespace:
    cmp  r13, 0
    je   .skip_ws

    ; end of token — copy to buffer and execute
    call .do_token

    ; After UNTIL, check for loop restart
    mov  rax, [begin_restart_ptr]
    cmp  rax, 0
    je   .after_restart
    ; Restart from saved BEGIN position
    mov  rbx, rax
    mov  qword [begin_restart_ptr], 0
    mov  r12, 0
    mov  r13, 0
    jmp  .scan_loop

.after_restart:
    mov  r13, 0

.skip_ws:
    inc  rbx
    jmp  .scan_loop

.process_last:
    cmp  r13, 0
    je   .done
    call .do_token

    ; Check restart one last time
    mov  rax, [begin_restart_ptr]
    cmp  rax, 0
    je   .done
    mov  rbx, rax
    mov  qword [begin_restart_ptr], 0
    mov  r12, 0
    mov  r13, 0
    jmp  .scan_loop

.done:
    pop  r14
    pop  r13
    pop  r12
    pop  rbx
    pop  rbp
    ret

; Internal helper — copy [r12..rbx) into token_buffer and call execute_token
; Uses r12 (start), rbx (one past end).  Clobbers rsi, rdi, rcx.
.do_token:
    push rax
    push rdi
    push rsi
    push rcx
    push r12
    push rbx

    mov  rsi, r12
    mov  rdi, token_buffer
    mov  rcx, rbx
    sub  rcx, rsi               ; length
    cmp  rcx, 0
    jle  .dt_skip
    push rcx
    rep  movsb
    pop  rcx
    mov  byte [rdi], 0

    cmp  byte [token_buffer], 0
    je   .dt_skip

    mov  rdi, token_buffer
    call execute_token

.dt_skip:
    pop  rbx
    pop  r12
    pop  rcx
    pop  rsi
    pop  rdi
    pop  rax
    ret

; ── execute_token ──────────────────────────────────────────
; void execute_token(char* token)
; Looks up the token and dispatches.  Control-flow words are
; always dispatched even when cf_should_skip() == 1 so that
; nesting counters stay accurate.
execute_token:
    push rbp
    mov  rbp, rsp
    push rbx
    mov  rbx, rdi               ; save token ptr

    ; ── Is this a control-flow keyword? (always executed) ──
    mov  rdi, rbx
    mov  rsi, dict_if
    call strcmp
    cmp  rax, 1
    jne  .chk_else
    ; IF: only consume TOS if we are NOT already skipping
    mov  rdi, rbx               ; dummy (control_if ignores arg)
    call control_if
    jmp  .done

.chk_else:
    mov  rdi, rbx
    mov  rsi, dict_else
    call strcmp
    cmp  rax, 1
    jne  .chk_then
    call control_else
    jmp  .done

.chk_then:
    mov  rdi, rbx
    mov  rsi, dict_then
    call strcmp
    cmp  rax, 1
    jne  .chk_begin
    call control_then
    jmp  .done

.chk_begin:
    mov  rdi, rbx
    mov  rsi, dict_begin
    call strcmp
    cmp  rax, 1
    jne  .chk_until
    ; Pass token address so control_begin can save it for UNTIL
    mov  rdi, rbx
    call control_begin
    jmp  .done

.chk_until:
    mov  rdi, rbx
    mov  rsi, dict_until
    call strcmp
    cmp  rax, 1
    jne  .not_cf
    call control_until          ; rax = 0 (exit) or BEGIN address (loop)
    mov  [begin_restart_ptr], rax
    jmp  .done

    ; ── Normal tokens: skip if inside false branch ──────
.not_cf:
    call cf_should_skip
    cmp  rax, 1
    je   .done                  ; suppress

    ; Try to parse as a number
    mov  rdi, rbx
    call is_number
    cmp  rax, 1
    jne  .check_words
    mov  rdi, rbx
    call string_to_number
    mov  rdi, rax
    call stack_push
    jmp  .done

.check_words:
    mov  rdi, rbx
    mov  rsi, dict_add
    call strcmp
    cmp  rax, 1
    jne  .cs_sub
    call op_add
    jmp  .done

.cs_sub:
    mov  rdi, rbx
    mov  rsi, dict_sub
    call strcmp
    cmp  rax, 1
    jne  .cs_mul
    call op_sub
    jmp  .done

.cs_mul:
    mov  rdi, rbx
    mov  rsi, dict_mul
    call strcmp
    cmp  rax, 1
    jne  .cs_div
    call op_mul
    jmp  .done

.cs_div:
    mov  rdi, rbx
    mov  rsi, dict_div
    call strcmp
    cmp  rax, 1
    jne  .cs_mod
    call op_div
    jmp  .done

.cs_mod:
    mov  rdi, rbx
    mov  rsi, dict_mod
    call strcmp
    cmp  rax, 1
    jne  .cs_dup
    call op_mod
    jmp  .done

.cs_dup:
    mov  rdi, rbx
    mov  rsi, dict_dup
    call strcmp
    cmp  rax, 1
    jne  .cs_drop
    call op_dup
    jmp  .done

.cs_drop:
    mov  rdi, rbx
    mov  rsi, dict_drop
    call strcmp
    cmp  rax, 1
    jne  .cs_swap
    call op_drop
    jmp  .done

.cs_swap:
    mov  rdi, rbx
    mov  rsi, dict_swap
    call strcmp
    cmp  rax, 1
    jne  .cs_over
    call op_swap
    jmp  .done

.cs_over:
    mov  rdi, rbx
    mov  rsi, dict_over
    call strcmp
    cmp  rax, 1
    jne  .cs_rot
    call op_over
    jmp  .done

.cs_rot:
    mov  rdi, rbx
    mov  rsi, dict_rot
    call strcmp
    cmp  rax, 1
    jne  .cs_dot
    call op_rot
    jmp  .done

.cs_dot:
    mov  rdi, rbx
    mov  rsi, dict_dot
    call strcmp
    cmp  rax, 1
    jne  .cs_emit
    call op_dot
    jmp  .done

.cs_emit:
    mov  rdi, rbx
    mov  rsi, dict_emit
    call strcmp
    cmp  rax, 1
    jne  .cs_cr
    call op_emit
    jmp  .done

.cs_cr:
    mov  rdi, rbx
    mov  rsi, dict_cr
    call strcmp
    cmp  rax, 1
    jne  .cs_space
    call op_cr
    jmp  .done

.cs_space:
    mov  rdi, rbx
    mov  rsi, dict_space
    call strcmp
    cmp  rax, 1
    jne  .cs_clear
    call op_space
    jmp  .done

.cs_clear:
    mov  rdi, rbx
    mov  rsi, dict_clear
    call strcmp
    cmp  rax, 1
    jne  .cs_pstack
    call op_clear
    jmp  .done

.cs_pstack:
    mov  rdi, rbx
    mov  rsi, dict_stack
    call strcmp
    cmp  rax, 1
    jne  .cs_bye
    call op_print_stack
    jmp  .done

.cs_bye:
    mov  rdi, rbx
    mov  rsi, dict_bye
    call strcmp
    cmp  rax, 1
    jne  .cs_help
    mov  rax, 60
    xor  rdi, rdi
    syscall

.cs_help:
    mov  rdi, rbx
    mov  rsi, dict_help
    call strcmp
    cmp  rax, 1
    jne  .unknown
    call show_help
    jmp  .done

.unknown:
    mov  rsi, unknown_cmd_msg
    call print_string
    mov  rsi, rbx
    call print_string
    mov  rsi, newline
    call print_string

.done:
    pop  rbx
    pop  rbp
    ret

; ── is_number ──────────────────────────────────────────────
is_number:
    push rbp
    mov  rbp, rsp
    mov  rsi, rdi
    cmp  byte [rsi], 0
    je   .no
    mov  al, [rsi]
    cmp  al, '-'
    jne  .check_digit
    inc  rsi
    mov  al, [rsi]
    cmp  al, 0
    je   .no
.check_digit:
    mov  al, [rsi]
    cmp  al, 0
    je   .yes
    cmp  al, '0'
    jl   .no
    cmp  al, '9'
    jg   .no
    inc  rsi
    jmp  .check_digit
.yes:
    mov  rax, 1
    pop  rbp
    ret
.no:
    mov  rax, 0
    pop  rbp
    ret

; ── string_to_number ───────────────────────────────────────
string_to_number:
    push rbp
    mov  rbp, rsp
    push rbx                    ; BUG-M3-01 FIX: save rbx (callee-saved)
    mov  rsi, rdi
    mov  rax, 0
    mov  rcx, 10
    mov  rdx, 0
    cmp  byte [rsi], '-'
    jne  .positive
    mov  rdx, 1
    inc  rsi
.positive:
    movzx rbx, byte [rsi]
    cmp  bl, 0
    je   .done
    sub  bl, '0'
    imul rax, rcx
    add  rax, rbx
    inc  rsi
    jmp  .positive
.done:
    cmp  rdx, 1
    jne  .finish
    neg  rax
.finish:
    pop  rbx                    ; BUG-M3-01 FIX: restore rbx
    pop  rbp
    ret

; ── strcmp ─────────────────────────────────────────────────
strcmp:
    push rbp
    mov  rbp, rsp
    push rbx
    push rsi
    push rdi
.loop:
    mov  al, [rdi]
    mov  bl, [rsi]
    cmp  al, bl
    jne  .ne
    cmp  al, 0
    je   .eq
    inc  rdi
    inc  rsi
    jmp  .loop
.eq:
    mov  rax, 1
    pop  rdi
    pop  rsi
    pop  rbx
    pop  rbp
    ret
.ne:
    mov  rax, 0
    pop  rdi
    pop  rsi
    pop  rbx
    pop  rbp
    ret

; ── show_prompt ────────────────────────────────────────────
show_prompt:
    push rbp
    mov  rbp, rsp
    mov  rsi, prompt
    call print_string
    pop  rbp
    ret

; ── get_input ──────────────────────────────────────────────
get_input:
    push rbp
    mov  rbp, rsp
    mov  rsi, rdi
    mov  r8,  rsi
    mov  rax, 0
    mov  rdi, 0
    mov  rdx, 255
    syscall
    mov  rcx, rax
    mov  rdi, r8
    cmp  rcx, 0
    je   .done
    cmp  byte [rdi + rcx - 1], 10
    jne  .done
    mov  byte [rdi + rcx - 1], 0
.done:
    pop  rbp
    ret

; ── show_help ──────────────────────────────────────────────
show_help:
    push rbp
    mov  rbp, rsp
    mov  rsi, help_msg1
    call print_string
    mov  rsi, help_msg2
    call print_string
    mov  rsi, help_msg3
    call print_string
    mov  rsi, help_msg4
    call print_string
    mov  rsi, help_msg5
    call print_string
    mov  rsi, help_msg6
    call print_string
    mov  rsi, help_msg7
    call print_string
    mov  rsi, help_msg8
    call print_string
    pop  rbp
    ret

; ── print_string ───────────────────────────────────────────
print_string:
    push rax
    push rdx
    mov  rdx, 0
.len:
    cmp  byte [rsi + rdx], 0
    je   .got
    inc  rdx
    jmp  .len
.got:
    mov  rax, 1
    mov  rdi, 1
    syscall
    pop  rdx
    pop  rax
    ret
